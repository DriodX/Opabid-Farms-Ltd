# Opabid-Farms-Ltd
A nice and big farm in Nigeria
